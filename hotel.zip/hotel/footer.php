<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    
    <title>AK HOTELS</title>

    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>

    <style>
            *{
                font-family:'poppins', sans-serif;
            }
            .g-font{
                font-family: 'merienda' , cursive;
            }
    </style>

</head>
<body>
        <div class="container-fluid shadow bg-white mt-5">
            <div class="row">
                <div class="col-lg-4 p-4">
                    <h3 class="g-font fw-bold fs-3 mb-2"> AK HOTEL </h3>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque exercitationem eaque adipisci excepturi ea maxime, sapiente, architecto in quis ipsum hic esse facilis! Beatae error necessitatibus a ipsam in asperiores.
                    </p>
                </div>
                <div class="col-lg-4 p-4">
                    <h5 class="mb-5"> Links </h5>
                    <a href="#" class="d-inline-block text-dark text-decoration-none mb-2"> Home </a> <br>
                    <a href="#" class="d-inline-block text-dark text-decoration-none mb-2"> Rooms </a><br>
                    <a href="#" class="d-inline-block text-dark text-decoration-none mb-2"> Facilities </a> <br>
                    <a href="#" class="d-inline-block text-dark text-decoration-none mb-2"> Contact </a> <br>
                    <a href="#" class="d-inline-block text-dark text-decoration-none mb-2"> About </a><br>
                </div>
                <div class="col-lg-4 p-4">
                     <h5 class="mb-5"> Follow us </h5>
                     <a href="#" class="d-inline-block text-dark text-decoration-none mb-2">
                        <i class="fa-brands fa-twitter pe-2"></i>twitter
                     </a> <br>
                     <a href="#" class="d-inline-block text-dark text-decoration-none mb-2">
                        <i class="fa-brands fa-facebook pe-2"></i>facebook
                     </a> <br>
                     <a href="#" class="d-inline-block text-dark text-decoration-none mb-2">
                        <i class="fa-brands fa-instagram pe-2"></i>instagram
                     </a> <br>
                </div> 
            </div>
            <h6 class="text-white bg-dark text-center p-3">Designed and Developed By AK Webdev</h6>
        </div>
</body>
</html>