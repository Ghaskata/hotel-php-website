<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>

    <style>
        *{
          font-family:'poppins', sans-serif;
        }
        .g-font{
          font-family: 'merienda' , cursive;
        }
        .h-line{
            width:150px;
            margin: 0 auto;
            height: 1.7px;
        }
        .pop:hover{
            border-top-color:#279e8c !important; 
            transform: scale(1.09);
            transition: all 0.5s; 
        }
    </style>

</head>
<body>
    
<!--  header  -->
<?php include "header.php" ?>

<!-- main -->

    <div class="container my-5 px-4">
        <h2 class="fw-bold text-center g-font"> Our Facilities </h2>
        <div class="h-line bg-dark"></div>
        <p class=" mt-3 text-center">Lorem ipsum dolor sit, amet consectetur adipisicing elit.
             Recusandae voluptates quis consectetur, <br>
             molestias sequi fugiat numquam? Qui voluptatem libero expedita.
        </p>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-5 px-4">
               <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                    <div class="d-flex align-items-center mb-2">
                        <img src="pics/rooms/wifi.jpg" width="40px">
                        <h5 class="m-0 ms-3"> Wifi </h5>
                    </div>
                    <p>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eveniet saepe adipisci totam assumenda maxime!
                    </p>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-5 px-4">
               <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                    <div class="d-flex align-items-center mb-2">
                        <img src="pics/rooms/wifi.jpg" width="40px">
                        <h5 class="m-0 ms-3"> Wifi </h5>
                    </div>
                    <p>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eveniet saepe adipisci totam assumenda maxime!
                    </p>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-5 px-4">
               <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                    <div class="d-flex align-items-center mb-2">
                        <img src="pics/rooms/wifi.jpg" width="40px">
                        <h5 class="m-0 ms-3"> Wifi </h5>
                    </div>
                    <p>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eveniet saepe adipisci totam assumenda maxime!
                    </p>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-5 px-4">
               <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                    <div class="d-flex align-items-center mb-2">
                        <img src="pics/rooms/wifi.jpg" width="40px">
                        <h5 class="m-0 ms-3"> Wifi </h5>
                    </div>
                    <p>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eveniet saepe adipisci totam assumenda maxime!
                    </p>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-5 px-4">
               <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                    <div class="d-flex align-items-center mb-2">
                        <img src="pics/rooms/wifi.jpg" width="40px">
                        <h5 class="m-0 ms-3"> Wifi </h5>
                    </div>
                    <p>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eveniet saepe adipisci totam assumenda maxime!
                    </p>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 mb-5 px-4">
               <div class="bg-white rounded shadow p-4 border-top border-4 border-dark pop">
                    <div class="d-flex align-items-center mb-2">
                        <img src="pics/rooms/wifi.jpg" width="40px">
                        <h5 class="m-0 ms-3"> Wifi </h5>
                    </div>
                    <p>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eveniet saepe adipisci totam assumenda maxime!
                    </p>
               </div>
            </div>
        </div>
    </div>

<!-- footer -->
<?php include "footer.php";?>

</body>
</html>