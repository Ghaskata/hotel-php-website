<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10.1.0/swiper-bundle.min.css">
    <script src="https://cdn.jsdelivr.net/npm/swiper@10.1.0/swiper-bundle.min.js"></script>
    <style>

    .g-font{
        font-family: 'merienda' , cursive;
    }
  
    *{
        font-family:'poppins', sans-serif;
      }
    
    .custom-bg:hover{
        
        transform: scale(1.1);
        transition: all 0.3s; 
    }
    .card:hover{
        transform: scale(1.03);
        transition: all 0.3s; 
        
    }
    .swiper {
      width: 100%;
      height: 100%;
    }

    .swiper-slide {
      background-position: center;
      background-size: cover;
    }

    .swiper-slide img {
      display: block;
      width: 100%;
    }
    /* #2eclac */
    </style>
    
</head>
<body>

<!--  header  -->
    <?php include "header.php" ?>

<!-- Rooms  -->
    
    <h2 class="mt-5 text-center fw-bold g-font"> Our Rooms </h2>

    <div class="container">
        <div class="row mt-5 mb-5">
            
            <div class="col-lg-4 col-md-6"> 
                    <div class="card shadow-lg" style="max-width:350px;">
                        <img src="pics/rooms/r1.jpg" class="card-img-top ">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Standard Rooms</h5>
                            <h6 class="mb-4"> ₹ 500 per night </h6> 
                            <p class="card-text">Perfect for the single person and for couple.A standard room can accommodate up to two guests.
                                The room may also have a small sitting area, such as a sofa or an armchair.</p>
                        <div class="mb-4">
                            <h6 class="mb-1">Rating</h6>
                            <span>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                            </span>
                        </div>
                        <div class="d-flex justify-content-evenly mb-3">
                            <a href="#" class="btn btn-md bg-info shadow-none custom-bg"> Book Now </a>
                            <a href="#" class="btn btn-md btn-outline-dark shadow-none custom-bg"> More Details</a>
                        </div>
                        </div>
                        
                    </div>
            </div>
            
            <div class="col-lg-4 col-md-6"> 
                    <div class="card shadow-lg" style="max-width:350px;">
                        <img src="pics/rooms/c5.jpg" class="card-img-top ">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Connect Room</h5>
                            <h6 class="mb-4"> ₹ 8000 per night </h6> 
                            <p class="card-text">These are two rooms connected by a locked adjoining door that can be opened by you and your fellow guests during your stay.
                            located next to each other, and these rooms have a connecting door. 
                            </p>
                        <div class="mb-4">
                            <h6 class="mb-1">Rating</h6>
                            <span>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                            </span>
                        </div>
                        <div class="d-flex justify-content-evenly mb-3">
                            <a href="#" class="btn btn-md btn-info shadow-none custom-bg"> Book Now </a>
                            <a href="#" class="btn btn-md btn-outline-dark shadow-none custom-bg"> More Details</a>
                        </div>
                        </div>
                        
                    </div>
            </div>

            <div class="col-lg-4 col-md-6"> 
               <div class="card shadow-lg" style="max-width:350px;">
                <img src="pics/rooms/d1.jpg" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title mb-3">Dulex Rooms</h5>
                    <h6 class="mb-4"> ₹ 1000 per night </h6> 
                    <p class="card-text">Deluxe rooms are usually larger than their standard counterparts, 
                        may include a bathtub and a shower in the bathroom.
                        Deluxe Plus rooms offer extra floor space along with exceptional design features.</p>
                    <div class="mb-4">
                        <h6 class="mb-1">Rating</h6>
                        <span>
                            <i class="fa-solid fa-star text-warning"></i>
                            <i class="fa-solid fa-star text-warning"></i>
                            <i class="fa-solid fa-star text-warning"></i>
                            <i class="fa-solid fa-star text-warning"></i>
                            <i class="fa-solid fa-star text-warning"></i>
                        </span>
                    </div>
                    <div class="d-flex justify-content-evenly mb-3">
                        <a href="#" class="btn btn-md btn-info shadow-none custom-bg"> Book Now </a>
                        <a href="#" class="btn btn-md btn-outline-dark shadow-none custom-bg"> More Details</a>
                    </div>
                    
                </div>
               </div>
            </div>
            
        </div>
        
        <div class="row mt-5 mb-5">

            <div class="col-lg-4 col-md-6"> 
                <div class="card shadow-lg" style="max-width:350px;">
                <img src="pics/rooms/s4.jpg" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title mb-3">Super Dulex Rooms</h5>
                    <h6 class="mb-4"> ₹ 2000 per night </h6> 
                    <p class="card-text">Super deluxe room is spacious provided with sofa's, 
                         bath room fitted with bath tubs.
                         Some of the Super deluxe rooms are carpeted and some are having wooden flooring.</p>
                    <div class="mb-4">
                        <h6 class="mb-1">Rating</h6>
                        <span>
                            <i class="fa-solid fa-star text-warning"></i>
                            <i class="fa-solid fa-star text-warning"></i>
                            <i class="fa-solid fa-star text-warning"></i>
                            <i class="fa-solid fa-star text-warning"></i>
                            <i class="fa-solid fa-star text-warning"></i>
                        </span>
                    </div>
                    <div class="d-flex justify-content-evenly mb-3">
                        <a href="#" class="btn btn-md btn-info shadow-none custom-bg"> Book Now </a>
                        <a href="#" class="btn btn-md btn-outline-dark shadow-none custom-bg"> More Details</a>
                    </div>
                    
                </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6"> 
                    <div class="card shadow-lg" style="max-width:350px;">
                        <img src="pics/rooms/l1.jpg" class="card-img-top ">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Luxury Rooms</h5>
                            <h6 class="mb-4"> ₹ 10000 per night </h6> 
                            <p class="card-text">Luxury Rooms are typically smaller, and have a clear creative sense and emphasis on design compared to traditional hotels.Beautiful views in every direction – inside and out.</p>
                        <div class="mb-4">
                            <h6 class="mb-1">Rating</h6>
                            <span>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                            </span>
                        </div>
                        <div class="d-flex justify-content-evenly mb-3">
                            <a href="#" class="btn btn-md btn-info shadow-none custom-bg"> Book Now </a>
                            <a href="#" class="btn btn-md btn-outline-dark shadow-none custom-bg"> More Details</a>
                        </div>
                        </div>
                        
                    </div>
            </div>

            <div class="col-lg-4 col-md-6"> 
                    <div class="card shadow-lg" style="max-width:350px;">
                        <img src="pics/rooms/su2.jpg" class="card-img-top ">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Suits</h5>
                            <h6 class="mb-4"> ₹ 15000 per night </h6> 
                            <p class="card-text">It usually refers to rooms together, like when you get a suite at a fancy hotel.
                                Suites class of accommodations with more space than a typical hotel room,but there should be more than one room to constitute a true suite.</p>
                        <div class="mb-4">
                            <h6 class="mb-1">Rating</h6>
                            <span>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                                <i class="fa-solid fa-star text-warning"></i>
                            </span>
                        </div>
                        <div class="d-flex justify-content-evenly mb-3">
                            <a href="#" class="btn btn-md btn-info shadow-none custom-bg"> Book Now </a>
                            <a href="#" class="btn btn-md btn-outline-dark shadow-none custom-bg"> More Details</a>
                        </div>
                        </div>
                        
                    </div>
            </div>

            
         
        </div>
    </div>

<!-- footer -->
<?php include "footer.php";?>

</body>
</html>