<?php
session_start(); 
  if (isset($_SESSION["username"])) {
    include "header2.php";
  }
  else {
    include "header.php" ; // Redirect to the login page if not logged in
  }
  
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'hotel';

$con = mysqli_connect($host,$user,$pass,$db);
$select = "SELECT * from tblrooms";
$exe = mysqli_query($con,$select);
$path = 'admin/';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10.1.0/swiper-bundle.min.css">
    <script src="https://cdn.jsdelivr.net/npm/swiper@10.1.0/swiper-bundle.min.js"></script>
    <style>

    .g-font{
        font-family: 'merienda' , cursive;
    }
  
    *{
        font-family:'poppins', sans-serif;
      }
    
    .custom-bg:hover{
        
        transform: scale(1.1);
        transition: all 0.3s; 
    }
    .card:hover{
        transform: scale(1.03);
        transition: all 0.3s; 
        
    }
    .swiper {
      width: 100%;
      height: 100%;
    }

    .swiper-slide {
      background-position: center;
      background-size: cover;
    }

    .swiper-slide img {
      display: block;
      width: 100%;
    }
    /* #2eclac */
    </style>
    
</head>
<body>

<!-- Rooms  -->
    
    <h2 class="mt-5 text-center fw-bold g-font"> Our Rooms </h2>

    <div class="container">
        <div class="row">
            <?php while ($row = mysqli_fetch_assoc($exe)){
                   $pic=$path.$row['rimage'];
            ?>
            <div class="col-lg-4 col-md-6 mt-5 mb-5"> 
                    <div class="card shadow-lg" style="max-width:350px;">
                        <img src="<?=$pic?>" width="100%" class="card-img-top ">
                        <div class="card-body">
                            <h5 class="card-title mb-4"><?= $row['rtype'] ?> </h5>
                            <h6 class="mb-4">₹  <?= $row['total'] ?> per night</h6> 
                            <!-- <p class="card-text">Perfect for the single person and for couple.A standard room can accommodate up to two guests.
                                The room may also have a small sitting area, such as a sofa or an armchair.</p> -->
                            <div class="mb-4">
                                <!-- 
                                  <h6 class="mb-1">Rating</h6> -->
                                  <span>
                                      <i class="fa-solid fa-star text-warning"></i>
                                      <i class="fa-solid fa-star text-warning"></i>
                                      <i class="fa-solid fa-star text-warning"></i>
                                      <i class="fa-solid fa-star text-warning"></i>
                                      <i class="fa-solid fa-star text-warning"></i>
                                  </span>
                            </div>
                            <div class="d-flex justify-content-evenly mb-3">
                                <a href="#" class="btn btn-md bg-info shadow-none custom-bg"> Book Now </a>
                                <a href="more_details.php?data=<?php echo urlencode($row['rtype']);?>" class="btn btn-md btn-outline-dark shadow-none custom-bg"> More Details</a>
                            </div>
                        </div>
                    </div>
            </div>
            <?php }?>
        </div>
    </div>

<!-- footer -->
<?php include "footer.php";?>

</body>
</html>