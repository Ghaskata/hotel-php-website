<?php

$host = "localhost";
$username = "root";
$password ="";

$con = mysql_connect($host,$username,$password);

 if($con)
     echo " connected ";

$db = mysql_select_db('hotel',$con);
if($con)
     echo " connected ";


$user = $_POST['username'];
$pass = $_POST['password'];

echo $user . '  ' . $pass;

$add = "INSERT into login values('$user','$pass')";
$e = mysql_query($add,$con);

if($e){
    echo 'inserted';
}
else{
    mysql_error();
}
//mysql_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <title>Document</title>
    <style>
        form{
            margin:40px;
        }
        label{
            text-align: center;
            padding: 30px;
            margin: 20px;
            font-size:30px;
        }
        input{
            text-align: center;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <div id="home">
        <center>
        <form method="post" action="index.php">
            <label> id </label>
            <input type="text" name="username"/>
            <br>
            <label> password </label>
            <input type="password" name="password"/>
            <br>
            
            <button class="btn btn-primary" type="submit"> submit </button>
        </form>
    </center>
    </div>    
</body>
</html>
