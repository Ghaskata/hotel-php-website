<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Hotel home page </title>
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>

   
    <style>
       *{
          font-family:'poppins', sans-serif;
        }
        .g-font{
          font-family: 'merienda' , cursive;
        }
        .carousel{
           height:100vh;
           min-height: 300px;
           background-size: cover;
           background: no-repeat scroll center scroll;
        }
        .carousel-item::before{
          background-color: black;
          opacity: 0.6;
          display: block;
          position: absolute;
          top:0;
          bottom:0;
          right:0;
          left:0;
          content: "";
        }
        .carousel-caption{
           top:30%;
          
        }
        .carousel-caption h5{
          font-size: 90px;
          font-family:'Times New Roman', Times, serif;
        }
        .check-avalibility{
          margin-top:-180px;
          z-index: 2;
          position: relative;
        }
        
        .custom-bg{
          text-align: center;
          width:100px;
          margin: 10px;
          padding : 10px;
          font-size: 25px;
          border: 1px solid CadetBlue;
          border-radius: 5px;
          background-color: CadetBlue ;
          color:white;
        }
        .custom-bg:hover{
          transform: scale(1.2);
        }
        
        .card-title{
          font-size: 25px;
          top: 45%;
          left:37%;
          position: absolute;
          text-align: center;
         }
        .card-img-overlay{
          width: 100%;
          height: 100%;
          top:0;
          left:0;
          position: absolute;
          background: rgba(0,0,0.5,0.6);
          display: flex;
          justify-content: center;
          align-items: center;
          flex-direction: column;
          opacity: 0;
          transition: 0.6s;
        }
        .card-img-overlay:hover{
          opacity: 1;
        }
        .a-btn{
          text-align: center;
        }
    </style>
    
<script>
  var myCarousel = document.querySelector('#myCarousel')
  var carousel = new bootstrap.Carousel(myCarousel, {
      interval: 3000,
      wrap: false,
  });
</script>

</head>

<body>

<!-- header -->
<?php include "header.php";?>

<!-- carousel -->
<div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <!-- <div class="carousel-item active">
      <img src="pics/.jpg" class="d-block w-100" alt="...">
    </div> -->
    <div class="carousel-item active">
      <img src="pics/2.jpg" class="d-block w-100" alt="...">
      
    </div>
    <div class="carousel-item">
      <img src="pics/3.jpg" class="d-block w-100" alt="...">
      
    </div>
    <div class="carousel-item">
      <img src="pics/4.jpg" class="d-block w-100" alt="...">
      
    </div>
    <div class="carousel-item">
      <img src="pics/5.jpg" class="d-block w-100" alt="...">
      
    </div>
  </div>
  <div class="carousel-caption d-none d-md-block">
        <h5> Amazing Services,<br> Location & Facilities </h5>
      </div>
</div>

<!-- check avaliblity of rooms -->
    <div class="container check-avalibility">
      <div class="row">
        <div class="col-lg-12 bg-white shadow p-4 rounded">
          <h5 class="mb-4"> Check Availability </h5>
          <form>
            <div class="row align-items-ends">
              <div class="col-lg-3 mb-3">
                <label class="form-label"> Check-in </label>
                <input type="date" class="form-control shadow-none"> 
              </div>
              <div class="col-lg-3 mb-3">
                <label class="form-label"> Check-out </label>
                <input type="date" class="form-control shadow-none"> 
              </div>
              <div class="col-lg-2 mb-3">
                <label class="form-label"> Guest </label>
                <select class="form-select" aria-label="Default select example">
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                  <option value="4">four</option>
                  <option value="5">five</option>
                </select>
              </div>
              <div class="col-lg-2 mb-3">
                <label class="form-label"> Rooms </label>
                <select class="form-select" aria-label="Default select example">
                  <option value="1">One</option>
                  <option value="2">Two</option>
                  <option value="3">Three</option>
                  <option value="4">four</option>
                  <option value="5">five</option>
                </select>
              </div>
              <div class="col-lg-2">
                <button type="submit" class="shadow-none custom-bg"> Book </button>
              </div>
            </div>
          </form>
        </div>
      </div>
</div>

<!-- rooms card -->
    <div class="container">
      <h2 class="mt-5 mb-5 text-center g-font"> Our Rooms </h2>
      <div class="row">
        <div class="col-lg-4 mb-4">
          <a href="rooms.php">
            <div class="card text-white rooms-card" style="max-width :350px;">
              <img class="card-img" src="pics/rooms/r2.jpg" alt="Card image">
              <div class="card-img-overlay">
                <h5 class="card-title"> Standard </h5>
              </div> 
            </div>
          </a>
        </div>
        <div class="col-lg-4 mb-4">
          <a href="rooms.php">
            <div class="card text-white rooms-card" style="max-width :350px;">
              <img class="card-img" src="pics/rooms/d2.jpg" alt="Card image">
              <div class="card-img-overlay">
                <h5 class="card-title"> Dulex </h5>
              </div> 
            </div>
          </a>
        </div>
        <div class="col-lg-4 mb-4">
          <a href="rooms.php">
            <div class="card text-white rooms-card" style="max-width :350px;">
              <img class="card-img" src="pics/rooms/l3.jpg" alt="Card image">
              <div class="card-img-overlay">
                <h5 class="card-title mr-3"> Luxury </h5>
              </div> 
            </div>
          </a>
        </div>
      </div>
      <div class="col-lg-12 text-center mt-5">
        <a href="rooms.php" class="btn btn-lg btn-outline-dark rounded-0 a-btn d-grid gap-2 col-3 mx-auto mb-5 mt-5"> More Rooms >>> </a>
      </div>
    </div>

<!-- facilitys -->
    <div class="container">
        <h2 class="mt-5 mb-5 text-center g-font"> Our Facilities </h2>
        <div class="row justify-content-evenly px-lg-0 px-md-0 px-5">
            <div class="col-lg-2 col-md-2 text-center bg-white shadow rounded py-4 my-3">
                <img src="pics/rooms/wifi.jpg" width="80px">
                <h5 class="mt-3">Wifi</h5>
            </div>
            <div class="col-md-2 col-lg-2 text-center bg-white shadow rounded py-4 my-3">
                <img src="pics/rooms/wifi.jpg" width="80px">
                <h5 class="mt-3">Wifi</h5>
            </div>
            <div class="col-md-2 col-lg-2 text-center bg-white shadow rounded py-4 my-3">
                <img src="pics/rooms/wifi.jpg" width="80px">
                <h5 class="mt-3">Wifi</h5>
            </div>
            <div class="col-md-2 col-lg-2 text-center bg-white shadow rounded py-4 my-3">
                <img src="pics/rooms/wifi.jpg" width="80px">
                <h5 class="mt-3">Wifi</h5>
            </div>
            <div class="col-md-2 col-lg-2 text-center bg-white shadow rounded py-4 my-3">
                <img src="pics/rooms/wifi.jpg" width="80px">
                <h5 class="mt-3">Wifi</h5>
            </div>
        </div>
        <div class="col-lg-12 text-center mt-5">
            <a href="facilities.php" class="btn btn-lg btn-outline-dark rounded-0 a-btn d-grid gap-2 col-3 mx-auto mb-5 mt-5"> More Facilities >>> </a>
        </div>
    </div>




    <!-- footer -->
    <?php include "footer.php";?>

</body>
</html>