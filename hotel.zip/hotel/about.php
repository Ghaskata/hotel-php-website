<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>

    <style>
        *{
          font-family:'poppins', sans-serif;
        }
        .g-font{
          font-family: 'merienda' , cursive;
        }
        .h-line{
            width:150px;
            margin: 0 auto;
            height: 1.7px;
        }
        .box:hover{
            border-top-color:#279e8c !important;
            
             
            transform: scale(1.09);
            transition: all 0.5s; 
        }
    </style>

</head>
<body>
    
<!--  header  -->
<?php include "header.php" ?>

<!-- main -->
    <div class="container my-5 px-4">
        <h2 class="fw-bold text-center g-font"> Our Facilities </h2>
        <div class="h-line bg-dark"></div>
        <p class=" mt-3 text-center">Lorem ipsum dolor sit, amet consectetur adipisicing elit.
             Recusandae voluptates quis consectetur, <br>
             molestias sequi fugiat numquam? Qui voluptatem libero expedita.
        </p>
    </div>
    
    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-4 border-top text-center box">
                    <img src="pics/about/a1.png" width="70px">
                    <h4 class="mt-3">100+ Rooms</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-4 border-top text-center box">
                    <img src="pics/about/a2.jpg" width="70px">
                    <h4 class="mt-3">200+ Customer</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-4 border-top text-center box">
                    <img src="pics/about/a2.png" width="70px">
                    <h4 class="mt-3">150+ Reviews</h4>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 px-4">
                <div class="bg-white rounded shadow p-4 border-4 border-top text-center box">
                    <img src="pics/about/a4.png" width="70px">
                    <h4 class="mt-3">250+ Staff</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-5">
        <div class="row justify-content-between align-items-center">
            <div class="col-lg-6 col-md-5 mb-4  order-md-1 order-lg-1 order-2">
                <h3 class="mb-3">Lorem ipsum dolor sit amet.</h3>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                    Sapiente itaque harum praesentium ad,
                    dolorum ipsam distinctio officiis quis optio sed quaerat libero laboriosam doloribus 
                    deserunt commodi autem dignissimos eius perspiciatis tempore fugit accusamus nam suscipit?
                    Corporis officia minus dicta eveniet iste! Delectus laborum temporibus aperiam labore dolorum ab. 
                    Modi odio a laborum debitis, iure nihil iusto earum optio esse.
                    Eum sit, quasi suscipit adipisci explicabo sequi.
                </p>
            </div>
            <div class="col-lg-5 col-md-5 mb-5 order-md-2 order-lg-2 order-1">
                <img src="pics/about/about.jpg" class="w-100">
            </div>
        </div>
    </div>

    
<!-- footer -->
<?php include "footer.php";?>

</body>
</html>