<?php

session_start(); 
  if (isset($_SESSION["username"])) {
    include "header2.php";
  }
  else {
    include "header.php" ; // Redirect to the login page if not logged in
  }
  
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'hotel';

if (isset($_GET['data'])) {
    // Retrieve and decode the passed string
    $room_type = urldecode($_GET['data']);

    $con = mysqli_connect($host,$user,$pass,$db);
    
    $select = "SELECT * FROM tbldetails AS d
               INNER JOIN tblrooms AS r ON d.rtype = r.rtype
               WHERE d.rtype = '$room_type'";
    
    $result = mysqli_query($con, $select);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $path = "admin/";
    } else {
        echo "Error executing the query: " . mysqli_error($con);
    }
    mysqli_close($con);
} 
else {
    echo "No data received.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10.1.0/swiper-bundle.min.css">
    <script src="https://cdn.jsdelivr.net/npm/swiper@10.1.0/swiper-bundle.min.js"></script>
    <style>

    .g-font{
        font-family: 'merienda' , cursive;
    }
  
    *{
        font-family:'poppins', sans-serif;
      }
    
    .btn:hover{
        transform: scale(1.2) ;
    }
    .amenities {
            list-style-type: none;
            padding: 0;
        }

        .amenities li {
            margin-bottom: 10px;
            font-size: 20px;
        }

        .amenities i {
            margin-right: 15px;
        }
        li {
            display: inline-block;
            margin-right: 20px; /* Adjust spacing between amenities */
        }
        .main{
            margin-top: 50%;
            z-index: 30;
        } 
</style>
    
</head>
<body>

<!-- Rooms  -->
    <!-- <div class="col-lg-3 mb-5 mt-5 pt-5 p-4 bg-white shadow-lg rounded">
                        <h6 class="mb-2">Rooms & Suits</h6>
                        <h3 class="mb-4">Hotel Booking From</h3>
                        <hr width="50%">
                        <form class="mb-2">
                            <div class="row mb-2 align-items-ends">
                                <div class="mb-4 ">
                                    <label class="form-label"> Check-in </label>
                                    <input type="date" class="form-control shadow-none"> 
                                </div>
                                <div class="mb-4">
                                    <label class="form-label"> Check-out </label>
                                    <input type="date" class="form-control shadow-none"> 
                                </div>
                                <div class="mb-4">
                                    <label class="form-label"> Guest </label>
                                    <select class="form-select" aria-label="Default select example">
                                            <option value="1"> One</option>
                                            <option value="2">  Two</option>
                                            <option value="3">  Three</option>
                                            <option value="4"> four</option>
                                            <option value="5">  five</option>
                                    </select>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label"> Rooms  </label>
                                    <select class="form-select" aria-label="Default select example">
                                        <option value="1">One   </option>
                                        <option value="2">Two   </option>
                                        <option value="3">Three   </option>
                                        <option value="4">four   </option>
                                        <option value="5">five   </option>
                                    </select>
                                </div>
                                <div class="mt-4 text-center">
                                    <button type="submit" class="btn btn-lg btn-dark shadow-none"> Check Availability </button>
                                </div>
                            </div>
                        </form>
                </div> -->
    <h2 class="mt-5 mb-5 text-center fw-bold g-font"> <?=$row['rtype']?> Rooms </h2>

    <!-- check avaliblity of rooms -->
    <div class="container check-avalibility">
            <div class="row">
                
                <div class="col-lg-8 mt-3 mb-3">
                    <img src="<?=$path.$row['img1']?>" class="rounded" width="100%">
                    <div class="row">
                        <div class="col-lg-4 mt-3">
                            <img src="<?=$path.$row['img2']?>" class="rounded" width="100%">
                        </div>
                        <div class="col-lg-4 mt-3">
                            <img src="<?=$path.$row['img3']?>" class="rounded" width="100%">
                        </div>
                        <div class="col-lg-4 mt-3">
                            <img src="<?=$path.$row['img4']?>" class="rounded" height="100%" width="100%">
                        </div>
                    </div>    
                </div>
                
                <div class="col-lg-4">
                    
                    <h3 class="mb-3 mt-5 fw-bold g-font"> Description </h3>
                    <p style="font-size:20px;"> <?=$row['rdesc']?>          
                    <h2 class="mb-4"> ₹ <?=$row['total']?> per night </h2>

                    <span style="font-size:20px;">
                        <i class="fa-solid fa-star text-warning"></i>
                        <i class="fa-solid fa-star text-warning"></i>
                        <i class="fa-solid fa-star text-warning"></i>
                        <i class="fa-solid fa-star text-warning"></i>
                        <i class="fa-solid fa-star text-warning"></i>
                    </span>
                    
                <div class="row">
                    <h3 class=" mb-3 mt-4 ps-3  fw-bold g-font"> Amenities </h3>
                    <ul class="amenities  ps-3">
                        <li><i class="fas fa-bed"></i> Comfortable Bed</li>
                        <li><i class="fas fa-wifi"></i> Free Wi-Fi</li>
                        <li><i class="fas fa-tv"></i> Flat-Screen TV</li>
                        <li><i class="fas fa-coffee"></i> Coffee Maker</li>
                        <li><i class="fas fa-shower"></i> Private Bathroom</li>
                    </ul>
                    <div class="d-flex mb-3">
                        <a href="#" class="btn btn-lg  ms-5 bg-info shadow-none custom-bg"> Book Now </a>
                        <a href="rooms.php" class="btn btn-lg ms-5  btn-dark shadow-none custom-bg"> Cancel </a>
                    </div>
                </div>
                   
                
                </div>
            
                
            </div>                         
    </div>

<!-- footer -->
<?php include "footer.php";?>

</body>
</html>