-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 10:19 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblbook`
--

CREATE TABLE `tblbook` (
  `id` int(11) NOT NULL,
  `check_in` datetime NOT NULL,
  `check_out` datetime NOT NULL,
  `rno` int(100) NOT NULL,
  `rtype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbook`
--

INSERT INTO `tblbook` (`id`, `check_in`, `check_out`, `rno`, `rtype`) VALUES
(1, '2023-09-16 00:00:00', '2023-09-21 00:00:00', 102, 'Dulex'),
(4, '2023-10-12 00:00:00', '2023-10-13 00:00:00', 103, 'Luxury'),
(14, '2023-09-14 00:00:00', '2023-09-11 00:00:00', 104, 'Connected'),
(15, '2023-09-21 00:00:00', '2023-09-28 00:00:00', 101, 'Simple'),
(16, '2023-09-20 00:00:00', '2023-09-29 00:00:00', 103, 'Luxury'),
(17, '2023-09-16 00:00:00', '2023-09-23 00:00:00', 106, 'Suits'),
(19, '2024-02-08 00:00:00', '2024-04-25 00:00:00', 104, 'Connected'),
(20, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 102, 'Dulex'),
(21, '2023-09-29 00:00:00', '2023-10-06 00:00:00', 102, 'Dulex'),
(22, '2023-09-14 00:00:00', '2023-09-29 00:00:00', 101, 'Simple'),
(23, '2023-09-21 00:00:00', '2023-09-28 00:00:00', 101, 'Simple'),
(24, '2023-09-30 00:00:00', '2023-10-04 00:00:00', 106, 'Suits'),
(25, '2023-09-15 00:00:00', '2023-09-16 00:00:00', 105, 'Super Dulex'),
(27, '2023-10-01 00:00:00', '2023-10-02 00:00:00', 101, 'Simple'),
(35, '2023-10-07 00:00:00', '2023-10-07 00:00:00', 101, 'Simple'),
(36, '2023-09-01 00:00:00', '2023-09-02 00:00:00', 101, 'Simple'),
(37, '2023-09-16 00:00:00', '2023-09-23 00:00:00', 104, 'Connected'),
(38, '2023-09-02 00:00:00', '2023-09-03 00:00:00', 104, 'Connected'),
(39, '2023-09-08 00:00:00', '2023-09-08 00:00:00', 102, 'Dulex'),
(40, '2023-09-06 00:00:00', '2023-09-06 00:00:00', 102, 'Dulex'),
(41, '2023-09-09 00:00:00', '2023-09-09 00:00:00', 102, 'Dulex'),
(42, '2023-09-10 00:00:00', '2023-09-10 00:00:00', 102, 'Dulex'),
(43, '2023-10-07 00:00:00', '2023-10-07 00:00:00', 104, 'Connected'),
(44, '2023-09-01 00:00:00', '2023-09-01 00:00:00', 104, 'Connected'),
(45, '2023-09-01 00:00:00', '2023-09-01 00:00:00', 105, 'Super Dulex'),
(46, '2023-10-27 00:00:00', '2023-10-28 00:00:00', 106, 'Suits'),
(47, '2023-11-05 00:00:00', '2023-11-05 00:00:00', 106, 'Suits'),
(48, '2023-10-07 00:00:00', '2023-10-07 00:00:00', 102, 'Dulex'),
(49, '2023-11-01 00:00:00', '2023-11-01 00:00:00', 102, 'Dulex'),
(50, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 101, 'Simple'),
(51, '2023-10-03 00:00:00', '2023-10-03 00:00:00', 101, 'Simple'),
(52, '2023-10-21 00:00:00', '2023-10-21 00:00:00', 101, 'Simple');

-- --------------------------------------------------------

--
-- Table structure for table `tbldetails`
--

CREATE TABLE `tbldetails` (
  `rtype` varchar(50) NOT NULL,
  `rdesc` varchar(1000) NOT NULL,
  `img1` blob NOT NULL,
  `img2` blob NOT NULL,
  `img3` blob NOT NULL,
  `img4` blob NOT NULL,
  `facility` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldetails`
--

INSERT INTO `tbldetails` (`rtype`, `rdesc`, `img1`, `img2`, `img3`, `img4`, `facility`) VALUES
('Connected', 'Two guest rooms are connected by a locked door to an adjoining room, which is also connected by a locked door. Adjoining rooms can be booked separately by two different people. What does a connecting suite mean? The trick is booking what the industry calls a connecting suite or connecting room instead of a traditional suite.', 0x75706c6f6164732f6d632e6a7067, 0x75706c6f6164732f63312e6a7067, 0x75706c6f6164732f63322e6a7067, 0x75706c6f6164732f63352e6a7067, ''),
('Dulex', 'Deluxe room: these rooms might be a bit bigger with slightly upgraded amenities or a nicer view. These rooms are typically equipped for groups who need more space, like a couple or small family. ', 0x75706c6f6164732f6d642e6a7067, 0x75706c6f6164732f64332e6a7067, 0x75706c6f6164732f64342e6a7067, 0x75706c6f6164732f64352e6a7067, ''),
('Luxury', 'A Luxury Hotel is considered a hotel that provides a luxurious accommodation experience to the guest. There are no set standards (such as stars) for luxury hotels. Often 4 or 5-star hotels describe themselves as â€˜luxuryâ€™.', 0x75706c6f6164732f6d6c2e6a7067, 0x75706c6f6164732f6c322e6a7067, 0x75706c6f6164732f6c332e6a7067, 0x75706c6f6164732f6c352e6a7067, ''),
('Simple', 'A minimalist room is designed and set up with less furniture and accessories for an uncluttered space. With furniture, dÃ©cor, storage and organization a minimalist room can be just what you want. Regardless of size and budget a bedroom or living room can be minimalist and still meet your needs.', 0x75706c6f6164732f6d732e6a7067, 0x75706c6f6164732f72322e6a7067, 0x75706c6f6164732f72332e6a7067, 0x75706c6f6164732f72342e6a7067, ''),
('Suits', 'A suite in a hotel or other public accommodation (e.g. a cruise ship) denotes, according to most dictionary definitions, connected rooms under one room number. Hotels may refer to suites as a class of accommodations with more space than a typical hotel room, but technically speaking there should be more than one room to constitute a true suite.', 0x75706c6f6164732f6d73752e6a7067, 0x75706c6f6164732f7375352e6a7067, 0x75706c6f6164732f7375322e6a7067, 0x75706c6f6164732f7375332e6a7067, ''),
('Super Dulex', 'Super Deluxe â€“ An exclusive and expensive luxury hotel, often palatial, offering the highest standards of service, accommodations and facilities. Elegant and luxurious public rooms. A prestigious address.', 0x75706c6f6164732f6d73642e6a7067, 0x75706c6f6164732f73352e6a7067, 0x75706c6f6164732f73322e6a7067, 0x75706c6f6164732f73312e6a7067, '');

-- --------------------------------------------------------

--
-- Table structure for table `tblrooms`
--

CREATE TABLE `tblrooms` (
  `rno` int(100) NOT NULL,
  `rtype` varchar(50) NOT NULL,
  `total` int(50) NOT NULL,
  `rimage` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrooms`
--

INSERT INTO `tblrooms` (`rno`, `rtype`, `total`, `rimage`) VALUES
(101, 'Simple', 2000, 0x75706c6f6164732f72312e6a7067),
(102, 'Dulex', 4000, 0x75706c6f6164732f64322e6a7067),
(103, 'Luxury', 15000, 0x75706c6f6164732f6c312e6a7067),
(104, 'Connected', 8000, 0x75706c6f6164732f63352e6a7067),
(105, 'Super Dulex', 10000, 0x75706c6f6164732f73342e6a7067),
(106, 'Suits', 20000, 0x75706c6f6164732f7375342e6a706567),
(107, 'simple', 2000, 0x75706c6f6164732f62672e6a7067),
(108, 'Connected', 30000, 0x75706c6f6164732f63352e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `birthdate` date NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`id`, `username`, `birthdate`, `phone`, `email`, `address`, `password`, `time`) VALUES
(1, 'kri', '2005-10-29', 757294361, 'Patelkrisha545@gmail.com', 'amroli', 'md5(123)', '0000-00-00 00:00:00'),
(2, 'aaa', '2007-12-01', 1235643210, 'aaa@gmail.com', 'amroli', '202cb962ac59075b964b07152d234b70', '0000-00-00 00:00:00'),
(41, 'bbb', '2002-09-22', 2147483647, 'aaa@gmail.com', 'amroli', '202cb962ac59075b964b07152d234b70', '2023-08-27 12:24:14'),
(48, 'ccc', '0004-10-01', 2147483647, 'Patelkrisha545@gmail.com', 'edfjidsjnmds', '202cb962ac59075b964b07152d234b70', '2023-08-28 14:08:59'),
(66, 'ddd', '2022-12-30', 2147483647, 'Patelkrisha545@gmail.com', 'eadszxc', '202cb962ac59075b964b07152d234b70', '2023-08-28 14:16:01'),
(67, 'eee', '2000-11-30', 2147483647, 'eee123@gmail.com', 'fsdfvfc', '202cb962ac59075b964b07152d234b70', '2023-08-28 14:22:19'),
(68, 'fff', '2007-08-28', 2147483647, 'Patelkrisha545@gmail.com', 'dscxz', '202cb962ac59075b964b07152d234b70', '2023-08-28 14:23:49'),
(72, 'abc', '2004-11-30', 2147483647, 'Patelkrisha545@gmail.com', 'sdsxzc ', '202cb962ac59075b964b07152d234b70', '2023-08-28 14:28:04'),
(74, 'prachi', '2004-11-30', 2147483647, 'Patelkrisha545@gmail.com', 'hukhrjs', '202cb962ac59075b964b07152d234b70', '2023-08-31 17:40:55'),
(75, 'jeet', '2012-09-26', 123457890, 'pateljeet123@gmail.com', 'amroli', '827ccb0eea8a706c4c34a16891f84e7b', '2023-09-01 10:27:49'),
(116, 'neha', '2010-11-30', 757294361, 'scs@yahoo.com', 'amroli', 'c6f057b86584942e415435ffb1fa93d4', '2023-09-01 10:53:54'),
(118, 'smit', '2022-11-30', 757294361, 'Patelkrisha545@gmail.com', 'sc', 'c6f057b86584942e415435ffb1fa93d4', '2023-09-01 10:55:08'),
(120, 'keyur', '2003-08-22', 1234567890, 'keyur03@gmail.com', 'velanja', 'cd3afef9b8b89558cd56638c3631868a', '2023-09-01 17:27:09'),
(122, 'admin', '2004-05-22', 1234567891, 'patelkrisha545@gmail.com', 'suart', 'fc73f5d41124557188f581b7448eccb9', '2023-09-03 12:09:16'),
(123, 'admin', '2023-09-25', 2147483647, 'Patelkrisha545@gmail.com', 'fsdsdv', '21232f297a57a5a743894a0e4a801fc3', '2023-09-18 17:59:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblbook`
--
ALTER TABLE `tblbook`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_rtype` (`rtype`);

--
-- Indexes for table `tbldetails`
--
ALTER TABLE `tbldetails`
  ADD PRIMARY KEY (`rtype`);

--
-- Indexes for table `tblrooms`
--
ALTER TABLE `tblrooms`
  ADD PRIMARY KEY (`rno`),
  ADD KEY `rtype` (`rtype`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`id`,`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblbook`
--
ALTER TABLE `tblbook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblbook`
--
ALTER TABLE `tblbook`
  ADD CONSTRAINT `fk_rtype` FOREIGN KEY (`rtype`) REFERENCES `tbldetails` (`rtype`);

--
-- Constraints for table `tblrooms`
--
ALTER TABLE `tblrooms`
  ADD CONSTRAINT `rtype` FOREIGN KEY (`rtype`) REFERENCES `tbldetails` (`rtype`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
