<?php

$host = 'localhost';
$username = 'root';
$password = '';

$con = mysqli_connect($host,$username,$password);

$db = mysqli_select_db($con,'hotel');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $errors = array(); // Store validation errors


$user = $_POST['user'];
$bdate = $_POST['bdate'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$add = $_POST['add'];
$pass = $_POST['pass'];
$cpass = $_POST['cpass'];

// Perform validation (e.g., check if fields are not empty, validate email format, etc.)
if (empty($user)) {
    $errors['user'] = "username is required.";
}
if (empty($bdate)) {
    $errors['bdate'] = "birthdate is required.";
}
if (empty($phone)) {
    $errors['phone'] = "phone number is required.";
}
if (strlen($phone) !== 10) {
    $errors['phone'] = "phone number is invalid";
}
if (empty($email)) {
    $errors['email'] = "email is required.";
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = "Invalid email format.";
}
if (empty($add)) {
    $errors['add'] = "address is required.";
}
if (empty($pass)) {
    $errors['pass'] = "it is required.";
}
if (empty($user)) {
    $errors['cpass'] = "its is required.";
}
if ($pass !== $cpass) {
    $errors['pass'] = "password in incorrect.";
}

}
    
$newpass= md5($pass);
$insert = " INSERT into tbluser (username,birthdate,phone,email,address,password) values ('$user','$bdate','$phone','$email','$add','$newpass')";
$run = mysqli_query($con,$insert);


if (empty($errors) && ($run === true)) {
    
    $response = array("success" => true);
}
else{
   
    $response = array("success" => false, "errors" => $errors);
}


// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);

?>
