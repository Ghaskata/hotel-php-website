
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>    
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>
    <title> AK HOTEL </title>

    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
    <script src="jquery.js"></script>

    <!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->

    <style>
      *{
        font-family:'poppins', sans-serif;
      }
      .g-font{
        font-family: 'merienda' , cursive;
      }
      tr,th{
        border: 2px 2px black;
        border-collapse: collapse;
        padding-right:10px;
        padding-bottom: 5px;
        padding-left: 10px;
        margin-right: 10px;
        margin-bottom: 5px;
      }
      /* Chrome, Safari, Edge, Opera */
      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        -webkit-appearance: none;
         margin: 0;
      }
      .text-danger{
          margin-top: 5px;
        }
     /* Firefox */
     input[type=number] {
          -moz-appearance: textfield;
     }
     a{
      color:white;
     }
     .sidebar {
         height: 100%;
         width: 200px;
         position: fixed;
         top: 20;
         left: 0;
         background-color:#1a0000; /*Change to your desired background color */
         padding-top: 20px;
         padding-right: 10px;
      }
      
      .sidebar a {
         padding: 10px 15px;
         text-decoration: none;
         font-size: 16px;
         color: #fff;
         display: block;
      }
      
      .sidebar a:hover {
         background-color: #555; /* Change to your desired hover color */
      }

      .content {
         margin-left: 200px; /* Adjust margin to match sidebar width */
         padding: 20px;
      }
    </style>
</head>

<body>

<!-- navbar  -->
<nav style="background-color:#1a0000;" class="navbar navbar-expand-lg px-lg-4 py-lg-2 shadow-sm sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand me-5 fw-bold fs-3 g-font" href="home.php"> AK HOTEL </a>
    <button class="navbar-toggler shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
      <div class="d-flex" role="search">
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-outline-secondary shadow-none me-lg-3 me-2 text-white" data-bs-toggle="modal" data-bs-target="#LogoutModal">
          Logout
        </button>
        <button type="button"  class="btn btn-outline-secondary shadow-none me-lg-3 me-2 text-white" data-bs-toggle="modal" data-bs-target="#ProfileModal">
          Profile
        </button>
      </div>
    </div>
  </div>
</nav>



<div class="modal fade" id="LogoutModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered ">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title d-flex align-items-center fs-5"><i class="fa-solid fa-circle-user fs-3 me-3"></i> Logout </h1>
        <button type="reset" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h3 class="d-flex text-center fs-5 mt-3 mb-4"> Are you sure to logout ? </h3>
        <div class="mb-3 d-flex" >
            <a class="text-center" href="./logout.php"><button type="submit" id="Submit" class="btn btn-lg btn-outline-dark shadow-none me-3 "> Logout </button> </a>
        </div>
      </div>
    </div>
  </div>
</div>
 
 
<div class="modal fade" id="ProfileModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title d-flex align-items-center fs-5"><i class="fa-solid fa-circle-user fs-3 me-3"></i> Your Details </h1>
        <button type="reset" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h3 class="d-flex text-center fs-5 mt-3 mb-4">  </h3>
        <div class="container-fluid">
          <table>
            <tr>
              <th> Username  </th>
              <td> <?php  echo ' : '. $user['username'] ;?> </td>
            </tr>
            <tr>
              <th> Birthdate : </th>
              <td> <?php  echo ' : '. $user['birthdate'] ;?> </td>
            </tr>
            <tr>
              <th> phone :   </th>
              <td> <?php  echo ' : '. $user['phone'] ;?> </td>
            </tr>
            <tr>
              <th> email : </th>
              <td> <?php  echo ' : '. $user['email'] ;?> </td>
            </tr>
            <tr>
              <th> address :   </th>
              <td> <?php  echo ' : '. $user['address'] ;?> </td>
            </tr>
          </table>
        </div>
        <div class="mb-3 mt-3 d-flex text-center" >
            <button type="submit" data-bs-dismiss="modal" class="btn btn-lg btn-outline-dark shadow-none me-3 "> OK </button> 
        </div>
      </div>
    </div>
  </div>

</body>
</html>