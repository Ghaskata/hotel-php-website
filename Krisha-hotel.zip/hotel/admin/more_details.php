<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>    
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>
    <title> AK HOTEL </title>

    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
    <script src="jquery.js"></script>

    <!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->

    <style>
      *{
        font-family:'poppins', sans-serif;
      }
      .g-font{
        font-family: 'merienda' , cursive;
      }
      tr,th{
        border: 2px 2px black;
        border-collapse: collapse;
        padding-right:10px;
        padding-bottom: 5px;
        padding-left: 10px;
        margin-right: 10px;
        margin-bottom: 5px;
      }
      /* Chrome, Safari, Edge, Opera */
      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        -webkit-appearance: none;
         margin: 0;
      }
      .text-danger{
          margin-top: 5px;
        }
     /* Firefox */
     input[type=number] {
          -moz-appearance: textfield;
     }
    </style>
</head>

<body>

<div class="container">
  <h1 class="g-font mb-5 mt-5 text-center"> update Rooms </h1>
  <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
      
      <div class="mb-3">
          <label for="Room_Type" class="form-label" >Room Type</label>
          <input type="text" class="form-control"  name="rtype" id="room_type" required>
      </div>
      <div class="mb-3">
          <label for="des" class="form-label" > Room desciption </label>
          <input type="text" class="form-control" name="rdesc" id="room_description" required>
      </div>
      <div class="mb-3">
          <label for="Room_img" class="form-label" >Room Image</label>
          <input type="file" class="form-control"  name="photo1" accept="image/*"  id="room_img1" required>
      </div>
      <div class="mb-3">
          <label for="Room_img" class="form-label" >Room Image</label>
          <input type="file" class="form-control"  name="photo2" accept="image/*"  id="room_img2" required>
      </div>
      <div class="mb-3">
          <label for="Room_img" class="form-label" >Room Image</label>
          <input type="file" class="form-control"  name="photo3" accept="image/*"  id="room_img3" required>
      </div>
      <div class="mb-3">
          <label for="Room_img" class="form-label" >Room Image</label>
          <input type="file" class="form-control"  name="photo4" accept="image/*"  id="room_img4" required>
      </div>
         
      <div class="text-center">
          <button type="submit" class="btn btn-primary mt-3 me-2" name="add"> ADD </button>
          <button type="submit" class="btn btn-primary mt-3 me-2 " name="update"> EDIT </button>
          <button type="submit" class="btn btn-primary mt-3 " name="delete"> DELETE </button>
      </div>
  </form>
</div>

</body>
</html>

<?php 

$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'hotel';

$con = mysqli_connect($host,$user,$pass,$db);

      if ($_SERVER["REQUEST_METHOD"] == "POST") {
          
          if (isset($_POST['add'])){
          
            $rtype = $_POST['rtype'];
            $rdesc = $_POST['rdesc'];
        
              // Check if a file was uploaded without errors
        
                  $targetDirectory = "uploads/";
                  $targetFile1 = $targetDirectory . basename($_FILES["photo1"]["name"]);
                  $targetFile2 = $targetDirectory . basename($_FILES["photo2"]["name"]);
                  $targetFile3 = $targetDirectory . basename($_FILES["photo3"]["name"]);
                  $targetFile4 = $targetDirectory . basename($_FILES["photo4"]["name"]);
      
                  if (move_uploaded_file($_FILES["photo1"]["tmp_name"], $targetFile1) &&
                      move_uploaded_file($_FILES["photo2"]["tmp_name"], $targetFile2) &&
                      move_uploaded_file($_FILES["photo3"]["tmp_name"], $targetFile3) &&
                      move_uploaded_file($_FILES["photo4"]["tmp_name"], $targetFile4)
                    ) {
                      //echo "Your file uploaded successfully.";
      
                      // Insert room information into the database
                      
                      $insertQuery = "INSERT INTO tbldetails (rtype,rdesc,img1,img2,img3,img4)  VALUES ('$rtype', '$rdesc', '$targetFile1','$targetFile2','$targetFile3','$targetFile4')";
                    }
                      if (mysqli_query($con, $insertQuery)) {
                          echo "<script> swal({
                                              text: ' Insert is successful . ',
                                              icon: 'success',
                                          }); </script>";
                      } else {
                          echo "Error: " . $insertQuery . "<br>" . mysqli_error($con);
                      }
                  } else {
                      echo "Sorry, there was an error uploading your file.";
                  }
              
            }
        
          if (isset($_POST['update'])){
    
            $rtype = $_POST['rtype'];
            $rdesc = $_POST['rdesc'];
        
            
                  $targetDirectory = "uploads/";
                  $targetFile1 = $targetDirectory . basename($_FILES["photo1"]["name"]);
                  $targetFile2 = $targetDirectory . basename($_FILES["photo2"]["name"]);
                  $targetFile3 = $targetDirectory . basename($_FILES["photo3"]["name"]);
                  $targetFile4 = $targetDirectory . basename($_FILES["photo4"]["name"]);
          
                  if (
                      move_uploaded_file($_FILES["photo1"]["tmp_name"], $targetFile1) &&
                      move_uploaded_file($_FILES["photo2"]["tmp_name"], $targetFile2) &&
                      move_uploaded_file($_FILES["photo3"]["tmp_name"], $targetFile3) &&
                      move_uploaded_file($_FILES["photo4"]["tmp_name"], $targetFile4)
                  ){
        
                      $update = "UPDATE tbldetails set  rdesc = '$rdesc',img1 = '$targetFile1' ,img2 = '$targetFile2',img3 = '$targetFile3',img4 = '$targetFile4' where rtype = '$rtype';";
      
                      if (mysqli_query($con, $update)) {
                        echo "<script> swal({
                          text: ' update is successful . ',
                          icon: 'success',
                      }); </script>";

                      } else {
                          echo "Error: " . $update . "<br>" . mysqli_error($con);
                      }
                  } 
              }

          if (isset($_POST['delete'])){
            
            $rtype = $_POST['rtype'];
            
            $delete = "DELETE from tbldetails where rtype = '$rtype';";
            if(mysqli_query($con,$delete)){
                    echo "<script> swal({
                                text: ' delete is successful . ',
                                icon: 'success',
                          }); </script>";
            }
          }
    
mysqli_close($con);

?>
