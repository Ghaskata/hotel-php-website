
<?php
session_start();
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'hotel';

    $con = mysqli_connect($host,$user,$pass,$db);

    $errors = array();
    
    if($_SERVER["REQUEST_METHOD"]=='POST'){

        $in = $_POST['c_in'];
        $out = $_POST['c_out'];


        if(empty($in)){
            $errors['in'] = "please Enter the date .";
        }
        if(empty($out)){
            $errors['out'] = "please Enter the date .";
        }
           
        if (isset($_GET['r_type'])) {
            $r_type = urldecode($_GET['r_type']);

                
            $query = "SELECT rno FROM tblrooms WHERE rtype = '$r_type'";
            $result = mysqli_query($con, $query);
            if(!$result){
                echo mysqli_error($con) ;
            }
            if($in > $out){
                    $errors['date']="check in date less than check out date ";
            }
            else{
                if ($result && mysqli_num_rows($result) > 0) {

                $row = mysqli_fetch_assoc($result);
                $room_number = $row['rno'];

                    $check = "SELECT COUNT(*) FROM tblbook 
                            WHERE rno = $room_number 
                            AND (('$in' BETWEEN check_in AND check_out) OR ('$out' BETWEEN check_in AND check_out))"; 
            
                    $v = mysqli_query($con, $check);

                if ($v) {
                    $count = mysqli_fetch_row($v);
                    if ($count[0] > 0) {
                            $errors['booking'] = "Room is already booked for overlapping dates.";
                    } 
                    else {
                        $add = "INSERT INTO tblbook (check_in, check_out,rno, rtype) VALUES ('$in', '$out',$room_number,'$r_type')";
                        $e = mysqli_query($con,$add);
                        if (!$e) {
                            $errors['booking'] = "Booking failed. Please try again later.";
                        }
                    }
                }
                else{
                $errors['database'] = mysqli_error($con);
                }
                }
                else {
                    $errors['database'] = "Room not found in the database.";
                }
            }

        }          
        
    }
            
    if (empty($errors)) {
        $response = array("success" => true);
    } else {
        $response = array("success" => false, "errors" => $errors);
    }


    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    

?>