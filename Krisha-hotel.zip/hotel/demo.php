 //if (isset($_GET['r_type'])) {
            $r_type = urldecode($_GET['r_type']);
            echo $r_type;   

            
        $query = "SELECT rno FROM tblrooms WHERE rtype = '$r_type'";
        $result = mysqli_query($con, $query);
       
        if($in > $out){
                $errors['date']="check in date less than check out date ";
        }
        else{
            if ($result && mysqli_num_rows($result) > 0) {

               $row = mysqli_fetch_assoc($result);
               $room_number = $row['rno'];

                $check = "SELECT COUNT(*) FROM tblbook 
                         WHERE rno = $room_number 
                        AND (('$in' BETWEEN check_in AND check_out) OR ('$out' BETWEEN check_in AND check_out))"; 
        
                $v = mysqli_query($con, $check);

            if ($v) {
                $count = mysqli_fetch_row($v);
                if ($count[0] > 0) {
                        $errors['booking'] = "Room is already booked for overlapping dates.";
                } 
                else {
                    $add = "INSERT INTO tblbook (check_in, check_out,rno, rtype) VALUES ('$in', '$out',$room_number,'$r_type')";
                    $e = mysqli_query($con,$add);
                    if (!$e) {
                        $errors['booking'] = "Booking failed. Please try again later.";
                    }
                }
            }
            else{
              $errors['database'] = mysqli_error($con);
            }
            }
            else {
                 $errors['database'] = "Room not found in the database.";
            }
        }

    // }          
        