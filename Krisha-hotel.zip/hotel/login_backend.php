<?php
    session_start();

    
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'hotel';

    $con = mysqli_connect($host,$user,$pass,$db);

    if($_SERVER["REQUEST_METHOD"]=='POST'){

        $username = $_POST['username'];
        $password = $_POST['password'];

        $errors = array();

        if(empty($username)){
            $errors['username'] = "please Enter the username .";
        }
        if(empty($password)){
            $errors['password'] = "please Enter the password .";
        }
    
    }

    $newpass = md5($password);
    $fetch = "SELECT * FROM tbluser where username ='".$username."' AND password = '".$newpass."';";
    $exe = mysqli_query($con,$fetch);
    $row = mysqli_num_rows($exe);
    
    

    if (empty($errors) && $row > 0) {    
        
        $_SESSION['username'] = $username;
        
        $response = array("success" => true,"redirect" => 'dashboard.php');

        
        
    }
    else{
        $errors['check'] = "Username or Password is incorrect .";
        $response = array("success" => false, "errors" => $errors);
    }
    
    
    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);

?>