<?php
session_start(); 
  if (isset($_SESSION["username"])) {
    include "header2.php";
  }
  else {
    include "header.php" ; // Redirect to the login page if not logged in
  }
  $con = mysqli_connect("localhost", "root", "", "hotel");
  
  if(isset($_POST['book'])){
    $in = $_POST['c_in'];
    $out = $_POST['c_out'];
    $r_type = $_POST['r_type'];
  
    $query = "SELECT rno FROM tblrooms WHERE rtype = '$r_type'";
    $result = mysqli_query($con, $query);
    
    if($in > $out){
      echo "<script>swal({
        text: ' invalid dates. ',
        icon: 'error',
      });</script>";
    }
    else{
    if ($result && mysqli_num_rows($result) > 0) {

        $row = mysqli_fetch_assoc($result);
        $room_number = $row['rno'];

        $check = "SELECT COUNT(*) FROM tblbook 
                  WHERE rno = $room_number 
                  AND (('$in' BETWEEN check_in AND check_out) OR ('$out' BETWEEN check_in AND check_out))"; 
          
          $v = mysqli_query($con, $check);
          if ($v) {
            
              $count = mysqli_fetch_row($v);
              if ($count[0] > 0) {
                echo "<script>swal({
                  text: ' Room is already booked for overlapping dates. ',
                  icon: 'error',
                });</script>";
              } else {
                    $add = "INSERT INTO tblbook (check_in, check_out,rno, rtype) VALUES ('$in', '$out',$room_number,'$r_type')";
                    $e = mysqli_query($con,$add);
                    echo "<script>swal({
                      text: ' Booking successfull. ',
                      icon: 'success',
                    });</script>";
              }
            }
      }
    }
  }
  

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Hotel home page </title>
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>    
    
   
    <style>
       *{
          font-family:'poppins', sans-serif;
        }
        .g-font{
          font-family: 'merienda' , cursive;
        }
        .carousel{
           height:100vh;
           min-height: 300px;
           background-size: cover;
           background: no-repeat scroll center scroll;
        }
        .carousel-item::before{
          background-color: black;
          opacity: 0.6;
          display: block;
          position: absolute;
          top:0;
          bottom:0;
          right:0;
          left:0;
          content: "";
        }
        .carousel-caption{
           top:30%;
          
        }
        .carousel-caption h5{
          font-size: 90px;
          font-family:'Times New Roman', Times, serif;
        }
        .check-avalibility{
          margin-top:-180px;
          z-index: 2;
          position: relative;
        }
        
        .custom-bg{
          text-align: center;
          width:100px;
          margin: 10px;
          padding : 10px;
          font-size: 25px;
          border: 1px solid CadetBlue;
          border-radius: 5px;
          background-color: CadetBlue ;
          color:white;
        }
        .custom-bg:hover{
          transform: scale(1.2);
        }
        
        .card-title{
          font-size: 25px;
          top: 45%;
          left:37%;
          position: absolute;
          text-align: center;
         }
        .card-img-overlay{
          width: 100%;
          height: 100%;
          top:0;
          left:0;
          position: absolute;
          background: rgba(0,0,0.5,0.6);
          display: flex;
          justify-content: center;
          align-items: center;
          flex-direction: column;
          opacity: 0;
          transition: 0.6s;
        }
        .card-img-overlay:hover{
          opacity: 1;
        }
        .a-btn{
          text-align: center;
        }
    </style>
    
<script>
  var myCarousel = document.querySelector('#myCarousel')
  var carousel = new bootstrap.Carousel(myCarousel, {
      interval: 3000,
      wrap: false,
  });
</script>

</head>

<body>

<!-- carousel -->
<div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <!-- <div class="carousel-item active">
      <img src="pics/.jpg" class="d-block w-100" alt="...">
    </div> -->
    <div class="carousel-item active">
      <img src="pics/2.jpg" class="d-block w-100" alt="...">
      
    </div>
    <div class="carousel-item">
      <img src="pics/3.jpg" class="d-block w-100" alt="...">
      
    </div>
    <div class="carousel-item">
      <img src="pics/4.jpg" class="d-block w-100" alt="...">
      
    </div>
    <div class="carousel-item">
      <img src="pics/5.jpg" class="d-block w-100" alt="...">
      
    </div>
  </div>
  <div class="carousel-caption d-none d-md-block">
        <h5> Amazing Services,<br> Location & Facilities </h5>
      </div>
</div>

<!-- check avaliblity of rooms -->
    <div class="container check-avalibility mb-5">
      <div class="row">
        <div class="col-lg-12 bg-white shadow p-4 rounded">
          <h5 class="mb-4"> Check Availability </h5>
          <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class="row align-items-ends">
              <div class="col-lg-3 mb-3">
                <label class="form-label"> Check-in Date : </label>
                <input type="date" id="c_in" name="c_in" class="form-control shadow-none"> 
              </div>
              <div class="col-lg-3 mb-3">
                <label class="form-label"> Check-out Date : </label>
                <input type="date" id="c_out" name="c_out" class="form-control shadow-none"> 
              </div>
              <div class="col-lg-3 mb-3">
                <label class="form-label"> Rooms Type : </label>
                <select id="r_type" name="r_type" class="form-select" aria-label="Default select example">
                <?php
                      
                      $result ="SELECT rtype FROM tbldetails";
                      $exe = mysqli_query($con,$result);
                      while ($row = mysqli_fetch_assoc($exe)) {
                            echo '<option value="' . $row['rtype'] . '">' . $row['rtype'] . '</option>';
                      }
                ?>
                </select>
              </div>
              <div class="col-lg-3 align-items-center">
                <button type="submit" name="book" class="shadow-none custom-bg"> Book </button>
              </div>
            </div>
          </form>
        </div>
      </div>
</div>

<!-- footer -->
<?php include "footer.php";?>

</body>
</html>