<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="icon\fontawesome-free-6.2.1-web\css\all.min.css">
    
  
    <link rel="stylesheet" href="bootstrap\bootstrap-5.1.3-dist\css\bootstrap.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>    
    <script src="bootstrap\bootstrap-5.1.3-dist\js\bootstrap.min.js"></script>
    
    <script src="jquery.js"></script>
    <title> AK HOTEL </title>
    <style>
      *{
        font-family:'poppins', sans-serif;
      }
      .g-font{
        font-family: 'merienda' , cursive;
      }
      /* Chrome, Safari, Edge, Opera */
      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        -webkit-appearance: none;
         margin: 0;
      }

     /* Firefox */
     input[type=number] {
          -moz-appearance: textfield;
     }
    </style>
</head>
<body>

<!-- navbar  -->
<nav class="navbar navbar-expand-lg navbar-light bg-white px-lg-4 py-lg-2 shadow-sm sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand me-5 fw-bold fs-3 g-font" href="home.php"> AK HOTEL </a>
    <button class="navbar-toggler shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active me-3" aria-current="page" href="home.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-3" href="rooms.php">Rooms</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-3" href="facilities.php">Facilities</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-3" href="#">Contact us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">About</a>
        </li>
      </ul>
      <div class="d-flex" role="search">
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-outline-dark shadow-none me-lg-3 me-2" data-bs-toggle="modal" data-bs-target="#LoginModal">
          Login
        </button>
        <button type="button" class="btn btn-outline-dark shadow-none me-lg-3 me-2" data-bs-toggle="modal" data-bs-target="#RegistreModal">
          Registre
        </button>
      </div>
    </div>
  </div>
</nav>

<!-- login  Modal -->
<div class="modal fade" id="LoginModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <form action="" id="login-form">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title d-flex align-items-center fs-5"><i class="fa-solid fa-circle-user fs-3 me-3"></i> Login </h1>
        <button type="reset" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label class="form-label"> username </label>
          <input type="text" class="form-control shadow-none" name='username' id='username'>
          <span class="login-error" id="username-error"></span>
        </div>
        <div class="mb-3">
          <label class="form-label">password</label>
          <input type="password" class="form-control shadow-none" name='password' id='password'>
          <span class="login-error" id="password-error"></span>
        </div>
        <span class="login-error" id="check-error"></span>
        <div class="mb-3 d-flex align-items-center justify-content-between" >
          <button type="submit" id="Login_Submit" class="btn btn-outline-dark shadow-none me-3"> LOGIN </button>
          <a href="#" class="text-secondary text-decoration-none"> Forgot password ? </a>
        </div>
      </div>
    </div>
  </div>
  </form>
  
</div>

<!-- register  Modal -->
<div class="modal fade" id="RegistreModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">

<form action="" method="post" id="regi-form">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title d-flex align-items-center fs-5">
          <i class="fa-solid fa-user-plus fs-3 me-3"></i> Registration 
        </h1>
        <button type="reset" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div>
               <span class="badge bg-light text-dark mb-4"> Note : fill all fileds be carefully fill all fileds be carefully.</span>
        </div> 

        <div class="container-fluid">
          <div class="row">
            <div class="col-md-6 ps-0 mb-4">
              <div class="mb-4">
                <label class="form-label"> Username </label>
                <input type="text" class="form-control shadow-none" name="user" id="user" required>
                <span class="error-message" id="user-error"></span>
              </div>
            </div>
            <div class="col-md-6 p-0 mb-4">
              <div class="mb-4">
                <label class="form-label"> Birth date </label>
                <input type="date" class="form-control shadow-none" name="bdate" id="bdate" required>
                <span class="error-message" id="bdate-error"></span>
              </div>
            </div>
          </div>
        
          <div class="row">
            <div class="col-md-6 ps-0 mb-3">
              <div class="mb-3">
                <label class="form-label"> Phone </label>
                <input type="number" class="form-control shadow-none" name="phone" id="phone" required>
                <span class="error-message" id="phone-error"></span>
              </div>
            </div>         
            <div class="col-md-6 p-0 mb-3">
              <div class="mb-3">
                <label class="form-label"> Email </label>
                <input type="Email" class="form-control shadow-none" name="email" id="email" required>
                <span class="error-message" id="email-error"></span>
              </div>
            </div>
          </div>  
          <div class="row">  
            <div class=" col-md-12 ps-0 mb-3">
              <label class="form-label"> Address </label>
              <div class="form-floating ">
                <textarea class="form-control shadow-none" name="add" id="add" placeholder="Leave a comment here" rows="1" required></textarea>
                <span class="error-message" id="add-error"></span>
              </div>
            </div>
          </div>  
          <div class="row">
            <div class="col-md-6 ps-0 mb-3">
              <div class="mb-3">
                <label class="form-label"> create password </label>
                <input type="password" class="form-control shadow-none" name="pass" id="pass" required>
              </div>
            </div>
            <div class="col-md-6 p-0 mb-3">
              <div class="mb-3">
                <label class="form-label"> confirm password </label>
                <input type="password" class="form-control shadow-none" name="cpass" id="cpass" required>
              </div>
            </div>
            <span class="error-message text-center" id="pass-error"></span>
          </div>
          <span class="error-message " id="user-exixt"></span>
        </div>
        <div class="text-center">
          <button type="submit" id="Regi_Submit" name="Submit" value="Submit" class="btn btn-outline-dark shadow-none me-3"> Register </button>
        </div>
      </div>
    </div>
  </div>
</form>
</div>

<script src="jquery.js" type="javascript"></script>
<script>
  $(document).ready(function() {
    // Handle the Save Changes button click
    $("#Regi_Submit").click(function(e) {
      e.preventDefault();
      var formData = $("#regi-form").serialize();
   
      $.ajax({
          type: "POST",
          url: "register_backend.php", // URL for your PHP processing script
          data: formData,
               
          success: function(response) {
                console.log(response);
                // Handle the response from the server (e.g., success message or error message)
                // Update the UI as needed
                if (response.success) {       
                  $("#RegistreModal").modal("hide");
                  swal({
                        title: "Good job!",
                        text: " Registeretion is successful . ",
                        icon: "success",
                  });
                  setTimeout(function() {
            location.reload(); // Reload the page
          }, 2000);        
                } 
                
                else
                {
                  $(".error-message").empty();      
                  if (response.errors) {
                      $.each(response.errors, function(key, message) {
                          $("#" + key + "-error").append("<p class='text-danger'>" + message + "</p>");
                      });
                  }
                  swal({
                        text: " Username is already exixts please change username . ",
                        icon: "error",
                  });
                }
          }
      });
    });
    $("#Login_Submit").click(function(e) {
        e.preventDefault();
        var formData1 = $("#login-form").serialize();

        $.ajax({
                  type: "POST",
                  url: "login_backend.php", // URL for your PHP processing script
                  data: formData1,
                  success: function(response) {
                              console.log(response);
          
                              if (response.success && response.redirect) 
                              {   
                                    $("#LoginModal").modal("hide");
                                    window.location.href = response.redirect;
                              } 
                              else
                              {
                                    $(".login-error").empty();      
                                    if (response.errors) {
                                            $.each(response.errors, function(key, message) {
                                            $("#" + key + "-error").append("<p class='text-danger'>" + message + "</p>");
                                    });
                              }
                  }
          }
      });
    });
});    
</script>        



</body>
</html>